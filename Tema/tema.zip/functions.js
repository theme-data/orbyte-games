$(document).ready(function(){

  const CONFIG = window.THEME_CONFIG || {};

  // Ajustes gerais  
  $('#cabecalho .span8.busca-mobile').after(`
      <div class="h-actions hidden-phone">
          <a href="/conta/login" class="h-user">
              <span>Entrar</span>
          </a>
      </div>
  `);
  
  $('#cabecalho .conteudo-topo .inferior').after(`
      <div class="h-actions visible-phone">
          <a href="/conta/login" class="h-user">
              <img src="https://cdn.awsli.com.br/2942/2942234/arquivos/user.svg" alt="Minha conta">
              <span>Entrar</span>
          </a>
  
          <div class="h-search visible-phone">
              <img src="https://cdn.awsli.com.br/2942/2942234/arquivos/search.svg" alt="Buscar">
          </div>
  
          <div class="h-menu visible-phone">
              <img src="https://cdn.awsli.com.br/2942/2942234/arquivos/menu.svg" alt="Menu">
          </div>
      </div>
  `);
  
  $('.banner.cheio .flex-direction-nav').prepend($('.banner.cheio .flex-control-nav'));
  
  // $('.selos li:first-child img').attr('src','https://cdn.awsli.com.br/2830/2830294/arquivos/site-protegido.svg');
  $('#rodape>div:last-child .conteiner .row-fluid div:not(.span12)').before(`<div class="feito-pixelset"><a href="https://www.pixelset.com.br/" class="pixel-logo" target="_blank"><img src="https://cdn.awsli.com.br/2942/2942234/arquivos/pixel-set.svg" alt="Pixelset"></a></div>`)
  $('#rodape>div:last-child .row-fluid > div:last-child').attr('style','')
  

  var whatsappNumbers = CONFIG.whatsappNumbers || [];
  
  var whatsappDropdownHtml = `
  <div class="whatsapp-dropdown">
      <button class="whatsapp-btn" type="button">
          <i class="fa fa-whatsapp"></i> Fale conosco pelo WhatsApp
      </button>
      <ul class="whatsapp-dropdown-menu" style="display: none;">
          ${whatsappNumbers.map(function(num) {
              return `<li>
                          <strong>${num.title}:</strong> <a href="https://wa.me/${num.phone}" target="_blank">${num.display}</a>
                      </li>`;
          }).join('')}
      </ul>
  </div>
  `;

  $('#rodape .institucional .lista-redes').after(whatsappDropdownHtml);

  $(function () {

    function updateHeaderOnScroll() {
        const $inferior = $('.conteudo-topo .inferior');

        if ($(window).width() <= 767) {

            if ($(window).scrollTop() > 10) {
                $inferior.addClass('scrolled');
            } else {
                $inferior.removeClass('scrolled');
            }

        } else {
            $inferior.removeClass('scrolled');
        }
    }

    $(window).on('scroll resize', updateHeaderOnScroll);

    updateHeaderOnScroll();

});

$(function () {

  function prepararSubmenus() {

      $('.nivel-um > li.com-filho').each(function () {

          const $item = $(this);

          // Evita duplicar o botão
          if (!$item.children('.toggle-submenu').length) {

              $item.append(`
                  <button 
                      type="button" 
                      class="toggle-submenu"
                      aria-label="Abrir submenu"
                  >
                      <span></span>
                  </button>
              `);

          }

          // Mobile começa fechado
          if ($(window).width() <= 767) {
              $item.children('ul').hide();
              $item.removeClass('menu-aberto');
          }

      });

  }


  // Clique SOMENTE na seta
  $(document).on('click', '.nivel-um > li.com-filho > .toggle-submenu', function (e) {

      e.preventDefault();
      e.stopPropagation();

      if ($(window).width() > 767) {
          return;
      }

      const $item = $(this).closest('li.com-filho');
      const $submenu = $item.children('ul').first();

      if ($item.hasClass('menu-aberto')) {

          $item.removeClass('menu-aberto');

          $submenu
              .stop(true, true)
              .slideUp(250);

      } else {

          // Fecha os outros
          $('.nivel-um > li.com-filho.menu-aberto')
              .not($item)
              .removeClass('menu-aberto')
              .children('ul')
              .stop(true, true)
              .slideUp(250);

          // Abre atual
          $item.addClass('menu-aberto');

          $submenu
              .stop(true, true)
              .slideDown(250);

      }

  });


  prepararSubmenus();


  $(window).on('resize', function () {

      if ($(window).width() > 767) {

          $('.nivel-um > li.com-filho')
              .removeClass('menu-aberto')
              .children('ul')
              .removeAttr('style');

      }

  });

});
  
  // Quando clicar no botão troca a classe do dropdown para abrir/fechar
  $(document).on('click', '.whatsapp-btn', function() {
      var $dropdown = $(this).closest('.whatsapp-dropdown');
      $dropdown.toggleClass('open');
      var $menu = $dropdown.find('.whatsapp-dropdown-menu');
      if ($dropdown.hasClass('open')) {
          $menu.slideDown(150);
      } else {
          $menu.slideUp(150);
      }
  });
  

  if (CONFIG.miniBannerPosicao) {
    $('.pagina-inicial .vitrine-' + CONFIG.miniBannerPosicao + ' + ul')
      .after($('.mini-banner'));
  }

  
  // Variáveis editáveis para as informações do atendimento
  const atendimento = CONFIG.atendimento || {};
  
  var atendimentoHtml = `
      <div class="span4 atendimento-rodape">
          <span class="titulo">${atendimento.titulo}</span>
          <ul>
              <li>${atendimento.horarios?.[0] || ''}</li>
              <li>${atendimento.horarios?.[1] || ''}</li>
              <li>${atendimento.horarios?.[2] || ''}</li>
              <li style="margin-top:10px;">
                  <img src="${atendimento.whatsapp?.icon}" alt="${atendimento.whatsapp?.alt}" style="vertical-align:middle; width:20px; margin-right:8px;">
                  ${atendimento.whatsapp?.number}
              </li>
              <li style="margin-top:5px;">
                  <img src="${atendimento.email?.icon}" alt="${atendimento.email?.alt}" style="vertical-align:middle; width:20px; margin-right:8px;">
                  <a href="mailto:${atendimento.email?.address}" style="color:inherit; text-decoration:none;">${atendimento.email?.address}</a>
              </li>
          </ul>
      </div>
  `;
  
  $('#rodape .sobre-loja-rodape').replaceWith(atendimentoHtml);
  
  // Defina as variáveis das categorias (imagem, link, alt e titulo)
  var categorias = CONFIG.categorias || [];
  
  // Montar os <li> dinamicamente usando as variáveis (inclui <span> com o título abaixo da imagem)
  var categoriaLis = categorias.map(function(c){
      return `<li class="c-item">
          <a href="${c.link}">
              <img src="${c.img}" alt="${c.alt}">
              <span class="c-titulo-categoria">${c.titulo}</span>
          </a>
      </li>`;
  }).join('');
  
  // Adiciona o bloco antes de #listagemProdutos
  $('.secao-banners').before(`
  <div class="c-slide-section">
      <ul class="c-slide">
          ${categoriaLis}
      </ul>
  </div>    
  `);

  /* =========================
    TEMA DO CABEÇALHO
  ========================== */
  (function () {
    var temaCabecalho = (
      window.THEME_CONFIG &&
      window.THEME_CONFIG.temaCabecalho
    ) || 'light';

    temaCabecalho = String(temaCabecalho).toLowerCase();

    if (temaCabecalho !== 'dark' && temaCabecalho !== 'light') {
      temaCabecalho = 'light';
    }

    $('body')
      .removeClass('tema-cabecalho-dark tema-cabecalho-light')
      .addClass('tema-cabecalho-' + temaCabecalho);
  })();
  
  // Ativa o Slick Slider na lista de categorias
  $('.c-slide').slick({
      slidesToShow: 9,
      slidesToScroll: 9,
      arrows: true,
      dots: false,
      infinite: false,
      responsive: [
          {
              breakpoint: 768,
              settings: {
                  slidesToShow: 5,
                  slidesToScroll: 5,
              }
          }
      ]
  });
  
/* Banner opcional acima de uma vitrine/categoria da home */
(function () {
  var bannersCategoriasHome = CONFIG.bannersCategoriasHome || [];

  function escaparHtml(valor) {
    return String(valor || '').replace(/[&<>'"]/g, function (caractere) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#039;',
        '"': '&quot;'
      }[caractere];
    });
  }

  function formatarTempo(totalSegundos) {
    var dias = Math.floor(totalSegundos / 86400);
    var horas = Math.floor((totalSegundos % 86400) / 3600);
    var minutos = Math.floor((totalSegundos % 3600) / 60);
    var segundos = totalSegundos % 60;

    return [dias, horas, minutos, segundos]
      .map(function (valor) {
        return String(valor).padStart(2, '0');
      })
      .join(' : ');
  }

  bannersCategoriasHome.forEach(function (banner) {
    if (!banner || !banner.ativo || !banner.idCategoria) return;

    var $vitrine = $('.pagina-inicial .vitrine-' + banner.idCategoria).first();

    if (!$vitrine.length || $('#banner-categoria-' + banner.idCategoria).length) {
      return;
    }

    var contadorHtml = banner.usarContador
      ? '<div class="banner-categoria-contador" data-data-fim="' +
        escaparHtml(banner.dataFim) +
        '">00 : 00 : 00 : 00</div>'
      : '';

    $vitrine.before([
      '<section class="banner-categoria-home" id="banner-categoria-' +
        escaparHtml(banner.idCategoria) + '">',
        '<div class="banner-categoria-conteudo">',
          '<strong class="banner-categoria-etiqueta">' +
            escaparHtml(banner.etiqueta) +
          '</strong>',
          contadorHtml,
          '<p class="banner-categoria-texto">' +
            escaparHtml(banner.titulo || banner.texto) +
          '</p>',
          '<a class="banner-categoria-botao" href="' +
            escaparHtml(banner.linkBotao || '#') +
          '">' +
            escaparHtml(banner.textoBotao || 'VER OFERTAS') +
          '</a>',
        '</div>',
      '</section>'
    ].join(''));
    
    /* Quando o contador estiver ativo:
        - remove o título da categoria;
        - adiciona classes na UL da vitrine. */
    if (banner.usarContador) {
      $vitrine
        .next('ul')
        .addClass('vitrine-com-banner-contador')
        .addClass('vitrine-categoria-' + banner.idCategoria);
    
      $vitrine.remove();
    }
  });

  function atualizarContadoresCategoria() {
    $('.banner-categoria-contador').each(function () {
      var $contador = $(this);
      var dataFim = new Date($contador.attr('data-data-fim')).getTime();
      var diferenca = Math.max(
        0,
        Math.floor((dataFim - Date.now()) / 1000)
      );

      if (!dataFim || diferenca <= 0) {
        $contador
          .closest('.banner-categoria-home')
          .addClass('banner-categoria-encerrado');

        $contador.text('OFERTA ENCERRADA');
        return;
      }

      $contador.text(formatarTempo(diferenca));
    });
  }

  if ($('.banner-categoria-contador').length) {
    atualizarContadoresCategoria();
    setInterval(atualizarContadoresCategoria, 1000);
  }
})();

// Carrossel de produtos
$('#listagemProdutos .listagem-linha .flex-viewport').css({
  overflow: 'visible'
});

$('#listagemProdutos .listagem-linha.flexslider').removeClass('flexslider');

if (typeof $.fn.slick === 'function') {
  $('#listagemProdutos ul .flex-viewport > ul').each(function () {
    const $slider = $(this);

    // Evita inicializar a mesma vitrine duas vezes
    if ($slider.hasClass('slick-initialized')) return;

    $slider.removeAttr('style');
    $slider.children('li').removeAttr('style');

    $slider.slick({
      dots: false,
      infinite: false,
      speed: 300,
      slidesToShow: 5,
      slidesToScroll: 1,
      responsive: [{
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          infinite: false,
          dots: true
        }
      }]
    });
  });
}
  
  
      // -----------------------------
    // BOTÃO
    // -----------------------------
    $('.info-principal-produto').after(
      '<button class="btn-forma-pagamento">Forma de pagamento</button>'
    );
  
    // -----------------------------
    // MODAL
    // -----------------------------
    $('body').append(`
      <div id="modal-pagamento">
        <div class="modal-conteudo"><div class="modal-header"><h3>Formas de pagamento</h3><button class="fechar-modal">✕</button></div></div>
      </div>
    `);
    
    $('.parcelas-produto').appendTo('#modal-pagamento .modal-conteudo');
    $(document).on('click', '.btn-forma-pagamento', function () {
      $('#modal-overlay, #modal-pagamento').addClass('ativo');
    });
    $(document).on('click', '.fechar-modal, #modal-overlay', function () {
      $('#modal-overlay, #modal-pagamento').removeClass('ativo');
    });
  
  $('.produto .conteiner-imagem #abreZoom').remove();
  
  $('.pagina-categoria .conteudo > .titulo').prepend($('.pagina-categoria .breadcrumbs'));
    $('.ordenar-listagem.topo > .row-fluid').prepend($('.pagina-categoria .conteudo > .titulo'));
    $('.ordenar-listagem .row-fluid > .span6').removeClass('span6');
    
    
  $(document).ready(function () {
  
      /* ======================================================
         1. CRIA BOTÃO FILTRAR
      ====================================================== */
  
      $('.ordenar-listagem.topo .row-fluid').append(`
          <button class="btn btn-filtrar" data-toggle="modal" data-target="#modalFiltros">
              Filtrar
          </button>
      `);
  
  
      /* ======================================================
         2. CRIA MODAL
      ====================================================== */
  
      $('body').append(`
          <div id="modalFiltros" class="modal fade" tabindex="-1" style="display: none;">
              <div class="modal-dialog modal-lg">
                  <div class="modal-content">
  
                      <div class="modal-header">
                          <h4 class="modal-title">Filtros</h4>
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                      </div>
  
                      <div class="modal-body">
                          <div class="modal-ordenar">
                            <h4>Ordenar por:</h4>
                          </div>
                          <div class="modal-filtros"></div>
                      </div>
  
                  </div>
              </div>
          </div>
      `);
  
  
      /* ======================================================
         3. MOVE DROPDOWN ORDENAR PARA O MODAL
      ====================================================== */
  
      $('.ordenar-listagem.topo .dropdown-menu')
          .appendTo('#modalFiltros .modal-ordenar');
  
  
      /* ======================================================
         4. MOVE TODOS OS FILTROS PARA O MODAL
      ====================================================== */
  
      $('.filtro-coluna').appendTo('#modalFiltros .modal-filtros');
  
  });
  
  /* =========================
   📢 MOVER BANNER PARA VITRINE (CONFIGURÁVEL)
==========================*/

if (CONFIG.bannerVitrine) {

  const vitrineSelector = `.pagina-inicial .vitrine-${CONFIG.bannerVitrine}`;

  $(vitrineSelector)
    .before($('.secao-banners .conteiner .banner.hidden-phone'));

}

  $('#barraNewsletter .componente .texto-newsletter').prepend($('#barraNewsletter .componente .titulo'));

  
  // FAQ
  
  $(function () {
  
      /* =========================
         📋 PERGUNTAS EDITÁVEIS
      ==========================*/
      const faqItems = CONFIG.faqItems || [];
    
    
      /* =========================
         🧱 MONTA HTML
      ==========================*/
      let faqHTML = `
        <section class="faq-section">
          <div class="faq-container">
            <h2>FAQ</h2>
            <p class="faq-subtitle">Dúvidas frequentes</p>
            <div class="faq-list">
      `;
    
      faqItems.forEach((item, index) => {
    
        faqHTML += `
          <div class="faq-item ${item.ativo ? 'active' : ''}">
            <div class="faq-pergunta">
              <span>${item.pergunta}</span>
              <div class="faq-icon">${item.ativo ? '−' : '+'}</div>
            </div>
    
            <div class="faq-resposta" style="${item.ativo ? 'display:block' : 'display:none'}">
              ${item.resposta}
            </div>
          </div>
        `;
      });
    
      faqHTML += `
            </div>
          </div>
        </section>
      `;
    
    
      /* =========================
         📍 INSERE NA HOME
      ==========================*/
      $('body.pagina-inicial #corpo, body.pagina-produto #corpo').after(faqHTML);
    
    
      /* =========================
         🎯 COMPORTAMENTO ACCORDION
      ==========================*/
      $(document).on('click', '.faq-pergunta', function () {
    
        const item = $(this).closest('.faq-item');
    
        // fecha outros
        $('.faq-item').not(item).removeClass('active')
          .find('.faq-resposta').slideUp(250);
    
        $('.faq-item').not(item)
          .find('.faq-icon').text('+');
    
        // toggle atual
        item.toggleClass('active');
    
        item.find('.faq-resposta').slideToggle(250);
    
        item.find('.faq-icon').text(
          item.hasClass('active') ? '−' : '+'
        );
    
      });
    
    });
    
  
    // Remove texto da bandeira
  
    $(function () {
  
      $('.bandeiras-produto .bandeira-promocao').each(function () {
    
        let texto = $(this).text();
    
        // remove a palavra "Desconto"
        texto = texto.replace(/desconto/i, '').trim();
    
        // pega apenas o número
        let numero = texto.replace('%', '').trim();
    
        // monta novo formato
        $(this).text(`-${numero}%`);
    
      });
    
    });

    $('.pagina-busca .ordenar-listagem.topo').prepend($('.pagina-busca .listagem > .titulo'));
  
  if ($(window).width() > 768) {
  //Desktop
      //$('.conteudo-topo .inferior').prepend($('.menu.superior'));
  
      $('.produto')
      .children()
      .not('.row-fluid:first')
      .appendTo('.conteiner-imagem');
  
      // Muda resolução das imagens
  
      $('.listagem .imagem-produto img').each(function () {
          var $img = $(this);
          var src = $img.attr('src');
  
          if (!src) return;
  
          // Troca 300x300 por 512x512
          var newSrc = src.replace('/300x300/', '/512x512/');
  
          // Só atualiza se realmente mudou
          if (newSrc !== src) {
          $img.attr('src', newSrc);
  
          // Se existir lazyload com data-src, atualiza também
          if ($img.attr('data-src')) {
              $img.attr('data-src', newSrc);
          }
          }
      });
      
      
      $('.mini-banner img').each(function () {
          var $img = $(this);
          var src = $img.attr('src');
  
          if (!src) return;
  
          // Troca 400x400 por 800x800
          var newSrc = src.replace('/400x400/', '/800x800/');
  
          if (newSrc !== src) {
          $img.attr('src', newSrc);
  
          // Se houver lazyload com data-src
          if ($img.attr('data-src')) {
              $img.attr('data-src', newSrc);
          }
          }
      });
  
      $('.pagina-produto .miniaturas img').each(function () {
  
          var $img = $(this);
          var src = $img.attr('src');
      
          if (!src) return;
      
          // troca SOMENTE 64x50 por 100x100
          var newSrc = src.replace('/64x50/', '/100x100/');
      
          if (newSrc !== src) {
      
              // src principal
              $img.attr('src', newSrc);
      
              // lazy load (se existir)
              if ($img.attr('data-src')) {
                  $img.attr('data-src', newSrc);
              }
      
              // atributos usados pela Loja Integrada
              if ($img.attr('data-mediumimg')) {
                  $img.attr(
                      'data-mediumimg',
                      $img.attr('data-mediumimg').replace('/64x50/', '/100x100/')
                  );
              }
      
              if ($img.attr('data-largeimg')) {
                  $img.attr(
                      'data-largeimg',
                      $img.attr('data-largeimg').replace('/64x50/', '/100x100/')
                  );
              }
          }
      
      });
  
      $(window).on('load', function () {
  
          $('.compre-junto__imagem img').each(function () {
      
              var $img = $(this);
              var src = $img.attr('src');
              if (!src) return;
      
              var newSrc = src.replace('/150x150/', '/300x300/');
      
              if (newSrc !== src) {
                  $img.attr('src', newSrc);
      
                  if ($img.attr('data-src')) {
                      $img.attr('data-src', newSrc);
                  }
              }
          });
      
      });
      
  
  //Fim desktop
  } else {
  //Mobile    
  $('.menu.superior').append(`<div class="close-menu"><img src="https://cdn.awsli.com.br/2923/2923109/arquivos/close.svg" alt="fechar"/></div>`);
  
  
  $(document).on('click', '.close-menu', function () {
    $('.menu.superior .nivel-um.active').removeClass('active');
  });
  
  $(document).on('click', '.h-menu', function () {
    $('.menu.superior .nivel-um').addClass('active');
  });
  
  $(document).on('click', '.h-search', function () {
    $('.conteudo-topo > .inferior').toggleClass('active');
  });
  
  $('.h-menu').before($('#cabecalho .conteudo-topo .inferior .span4.hidden-phone > .carrinho'));

    // adiciona o ícone
    $('.links-rodape .titulo, .atendimento-rodape .titulo, .visible-phone .titulo')
    .each(function(){
      if (!$(this).find('.chev').length) {
        $(this).append('<span class="chev"><img src="https://cdn.awsli.com.br/2942/2942234/arquivos/chevron_fdown.svg"/></span>');
      }
    });

  // toggle no click
  $('.links-rodape .titulo, .atendimento-rodape .titulo, .visible-phone .titulo')
    .on('click', function(){

      var $parent = $(this).parent();
      var $ul = $parent.find('ul');

      $ul.toggleClass('open');
      $(this).toggleClass('open');

    });

  
  //Fim mobile
  }

  var tarja = CONFIG.tarja || [];

  var tarjaItems = tarja.map(function(t){
    return `
      <div class="t-item">
        <div class="tarja-img">
          <img src="${t.icon}" alt="${t.titulo}">
        </div>
        <div class="t-text">
          <strong>${t.titulo}</strong>
          <span>${t.texto}</span>
        </div>
      </div>
    `;
  }).join('');

  $('.pagina-inicial .secao-banners').after(`
    <div class="t-bar">
      <div class="t-slide">
        ${tarjaItems}
      </div>
    </div>
  `);

  $('.t-slide').slick({
    slidesToShow: 4,
    arrows: false,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 0,
    speed: 4000,
    cssEase: 'linear',
    pauseOnHover: false,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1
        }
      }
    ]
  });

  // MOVE TARJA


  var vitrineTarja = CONFIG.vitrineTarja || {};

  if (vitrineTarja.idVitrine) {
    $(`.pagina-inicial .vitrine-${vitrineTarja.idVitrine}`)
      .before($('.banner.tarja'));
  }

  //ALERTA DIGITAL 

  if (typeof CONFIG === "undefined") return;

  var conf = CONFIG.alertaProduto || {};
  var icon = conf.icon || "";
  var texto = conf.texto || "";

  var $target = $('.pagina-produto .produto .cep');

  if ($target.length && !$('.alert-envio-digital').length) {
    $target.before(`
      <div class="alert-envio-digital">
        ${icon ? `<i><img src="${icon}" alt=""></i>` : ``}
        ${texto}
      </div>
    `);
  }

  var textoAlertBar = CONFIG.alertBar || {};

  if (textoAlertBar.mensagem) {
    $('.barra-inicial')
      .replaceWith(`
        <div class="alert-bar">
          <span>${textoAlertBar.mensagem}</span>
        </div>
      `);
  }

  /* ======================================================
      VITRINE DESTAQUE
    ====================================================== */
    var vitrineDestaque = CONFIG.vitrineDestaque || {};
    var id = vitrineDestaque.idVitrine;

    if (id) {
      var $tituloVitrine = $('.pagina-inicial .vitrine-' + id).first();
      var $listaVitrine = $tituloVitrine.next('ul');

      function converterPreco(texto) {
        if (!texto) return 0;

        var valor = String(texto)
          .replace(/[^\d,]/g, '')
          .replace(',', '.');

        return parseFloat(valor) || 0;
      }

      function obterDesconto($produto) {
        var precoAntigo = converterPreco(
          $produto.find(
            '.preco-produto .preco-antigo, .preco-produto del, .preco-produto .preco-base'
          ).first().text()
        );

        var precoAtual = converterPreco(
          $produto.find(
            '.preco-produto strong.titulo, .preco-produto .preco-promocional'
          ).last().text()
        );

        if (precoAntigo > precoAtual && precoAtual > 0) {
          return Math.round((1 - precoAtual / precoAntigo) * 100);
        }

        return 0;
      }

      if ($listaVitrine.length) {
        $listaVitrine.addClass('vitrine-destaque-produtos');

        $listaVitrine.find('.listagem-item').each(function () {
          var $produto = $(this);

          if ($produto.hasClass('vitrine-destaque-pronto')) return;

          $produto.addClass('vitrine-destaque-pronto');

          var $imagem = $produto.find('.imagem-produto').first();
          var $nome = $produto.find('.nome-produto a').first();
          var linkProduto =
            $nome.attr('href') ||
            $produto.find('a').first().attr('href') ||
            '#';

          var percentualDesconto = vitrineDestaque.mostrarDesconto !== false
            ? obterDesconto($produto)
            : 0;

          var textoSelo = percentualDesconto > 0
            ? '-' + percentualDesconto + '% OFF'
            : (vitrineDestaque.seloPadrao || 'OFERTA EM DESTAQUE');

          if ($imagem.length && !$imagem.find('.vitrine-destaque-selo').length) {
            $imagem.append(
              '<span class="vitrine-destaque-selo">' + textoSelo + '</span>'
            );
          }

          if (!$produto.find('.vitrine-destaque-cta').length) {
            $produto.find('.info-produto').append(
              '<a class="vitrine-destaque-cta" href="' + linkProduto + '">' +
                (vitrineDestaque.textoBotao || 'VER OFERTA') +
                '<span>→</span>' +
              '</a>'
            );
          }
        });
      }
    }

  
});

/* =========================
  OFERTAS DESTACADAS
========================== */
(function () {
  var configOfertas = (window.THEME_CONFIG && window.THEME_CONFIG.ofertasDestacadas) || {};

  if (!configOfertas.ativo) return;

  var ofertas = (configOfertas.ofertas || []).filter(function (oferta) {
    return oferta && oferta.ativo;
  });

  if (!ofertas.length || $('#ofertas-destacadas').length) return;

  function escaparHtml(valor) {
    return String(valor || '').replace(/[&<>"']/g, function (caractere) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      }[caractere];
    });
  }

  function iconeTag() {
    return [
      '<svg viewBox="0 0 24 24" aria-hidden="true">',
        '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3.4 13.4a2 2 0 0 1-.6-1.4V5a2 2 0 0 1 2-2h7a2 2 0 0 1 1.4.6l7.4 7a2 2 0 0 1 0 2.8Z"></path>',
        '<circle cx="7.5" cy="7.5" r="1.1"></circle>',
      '</svg>'
    ].join('');
  }

  var ofertasHtml = ofertas.map(function (oferta, indice) {
    var tipo = oferta.tipo || 'link';
    var botao;

    if (tipo === 'cupom') {
      botao = [
        '<button type="button" class="oferta-destaque-botao js-copiar-cupom" ',
          'data-cupom="', escaparHtml(oferta.cupom), '">',
          escaparHtml(oferta.textoBotao || 'COPIAR'),
        '</button>'
      ].join('');
    } else {
      botao = [
        '<a class="oferta-destaque-botao" href="', escaparHtml(oferta.link || '#'), '">',
          escaparHtml(oferta.textoBotao || 'VER OFERTAS'),
        '</a>'
      ].join('');
    }

    return [
      '<article class="oferta-destaque-item" data-oferta="', indice, '">',
        '<div class="oferta-destaque-icone">', iconeTag(), '</div>',
        '<div class="oferta-destaque-textos">',
          '<strong>', escaparHtml(oferta.titulo), '</strong>',
          '<span>', escaparHtml(oferta.descricao), '</span>',
        '</div>',
        botao,
      '</article>'
    ].join('');
  }).join('');

  var html = [
    '<div id="ofertas-destacadas" class="ofertas-destacadas">',
      '<button type="button" class="ofertas-destacadas-aba" aria-label="Abrir ofertas especiais">',
        '<span class="ofertas-destacadas-aba-icone">', iconeTag(), '</span>',
        '<span>', escaparHtml(configOfertas.tituloAba || 'Ofertas para você'), '</span>',
      '</button>',

      '<div class="ofertas-destacadas-overlay"></div>',

      '<aside class="ofertas-destacadas-painel" aria-hidden="true">',
        '<header class="ofertas-destacadas-header">',
          '<h2>', escaparHtml(configOfertas.tituloPainel || 'Ofertas especiais'), '</h2>',
          '<button type="button" class="ofertas-destacadas-fechar" aria-label="Fechar ofertas">×</button>',
        '</header>',

        '<div class="ofertas-destacadas-lista">',
          ofertasHtml || '<p class="ofertas-destacadas-vazio">' +
            escaparHtml(configOfertas.textoVazio || 'Nenhuma oferta disponível no momento.') +
          '</p>',
        '</div>',
      '</aside>',
    '</div>'
  ].join('');

  $('body').append(html);

  var $container = $('#ofertas-destacadas');

  function abrirOfertas() {
    $container.addClass('ofertas-abertas');
    $container.find('.ofertas-destacadas-painel').attr('aria-hidden', 'false');
    $('body').addClass('ofertas-destacadas-abertas');
  }

  function fecharOfertas() {
    $container.removeClass('ofertas-abertas');
    $container.find('.ofertas-destacadas-painel').attr('aria-hidden', 'true');
    $('body').removeClass('ofertas-destacadas-abertas');
  }

  $container.on('click', '.ofertas-destacadas-aba', abrirOfertas);
  $container.on('click', '.ofertas-destacadas-fechar, .ofertas-destacadas-overlay', fecharOfertas);

  $(document).on('keydown', function (evento) {
    if (evento.key === 'Escape') fecharOfertas();
  });

  $container.on('click', '.js-copiar-cupom', function () {
    var $botao = $(this);
    var cupom = $botao.attr('data-cupom') || '';
    var textoOriginal = $botao.text();

    function feedback() {
      $botao.text('COPIADO!');
      setTimeout(function () {
        $botao.text(textoOriginal);
      }, 1800);
    }

    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(cupom).then(feedback);
      return;
    }

    var campo = document.createElement('textarea');
    campo.value = cupom;
    campo.style.position = 'fixed';
    campo.style.opacity = '0';
    document.body.appendChild(campo);
    campo.select();
    document.execCommand('copy');
    document.body.removeChild(campo);
    feedback();
  });

  if (configOfertas.abrirAutomaticamente) {
    setTimeout(abrirOfertas, 800);
  }
})();

/* =========================
  BOTÃO WHATSAPP — LISTAGEM
========================== */
(function () {
  var configWhatsapp = (
    window.THEME_CONFIG &&
    window.THEME_CONFIG.whatsappListagem
  ) || {};

  if (!configWhatsapp.ativo || !configWhatsapp.telefone) return;

  function obterNomeProduto($produto) {
    return (
      $produto.find('.nome-produto').first().text() ||
      $produto.find('.produto-nome').first().text() ||
      $produto.find('a[data-produto-id]').first().attr('title') ||
      $produto.find('img').first().attr('alt') ||
      'Produto da loja'
    ).trim();
  }

  function obterLinkProduto($produto) {
    var link = (
      $produto.find('.nome-produto a').first().attr('href') ||
      $produto.find('.produto-nome a').first().attr('href') ||
      $produto.find('a[href*="/produto/"]').first().attr('href') ||
      $produto.find('a').first().attr('href') ||
      ''
    );

    if (link && link.indexOf('http') !== 0) {
      link = window.location.origin + link;
    }

    return link || window.location.href;
  }

  function criarBotaoWhatsapp($produto) {
    if ($produto.find('.botao-comprar-whatsapp').length) return;

    var nomeProduto = obterNomeProduto($produto);
    var linkProduto = obterLinkProduto($produto);

    var mensagem = String(
      configWhatsapp.mensagem ||
      'Olá! Tenho interesse neste produto:\n\n{produto}\n{link}'
    )
      .replace(/\{produto\}/gi, nomeProduto)
      .replace(/\{link\}/gi, linkProduto);

    var urlWhatsapp =
      'https://wa.me/' +
      String(configWhatsapp.telefone).replace(/\D/g, '') +
      '?text=' +
      encodeURIComponent(mensagem);

    var target = configWhatsapp.novaAba !== false
      ? ' target="_blank" rel="noopener noreferrer"'
      : '';

    var html = [
      '<a class="botao-comprar-whatsapp" href="', urlWhatsapp, '"', target, '>',
        '<img src="https://cdn.awsli.com.br/2942/2942234/arquivos/whatsapp.png" alt="Whatsapp"/>',
        '<span>', configWhatsapp.textoBotao || 'COMPRE PELO WHATSAPP', '</span>',
      '</a>'
    ].join('');

    /* Insere abaixo do botão de comprar de cada produto */
    var $acoes = $produto.find('.acoes-produto').first();

    if ($acoes.length) {
      $acoes.append(html);
    } else {
      $produto.find('.produto-info, .info-produto').first().append(html);
    }
  }

  function adicionarBotoesWhatsapp() {
    $('.listagem .listagem-item, .vitrine .listagem-item').each(function () {
      criarBotaoWhatsapp($(this));
    });
  }

  adicionarBotoesWhatsapp();

  var observer = new MutationObserver(function () {
    adicionarBotoesWhatsapp();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
})();

/* ======================================================
   AVALIAÇÕES — HOME | Slick Carousel
====================================================== */
(function () {
  var config = (
    window.THEME_CONFIG &&
    window.THEME_CONFIG.avaliacoesHome
  ) || {};

  if (!config.ativo || $('#avaliacoes-home').length) return;

  /* Exibe apenas na home, salvo se somenteHome for false */
  if (
    config.somenteHome !== false &&
    !$('body').hasClass('pagina-inicial') &&
    !$('.pagina-inicial').length
  ) {
    return;
  }

  function escaparHtml(valor) {
    return String(valor || '').replace(/[&<>"']/g, function (caractere) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      }[caractere];
    });
  }

  function criarEstrelas(nota) {
    var notaFinal = Math.min(5, Math.max(0, parseFloat(nota) || 5));
    var html = '';

    for (var i = 1; i <= 5; i++) {
      var classe = i <= Math.ceil(notaFinal)
        ? 'avaliacoes-home-estrela ativa'
        : 'avaliacoes-home-estrela';

      html += [
        '<svg class="', classe, '" viewBox="0 0 24 24" aria-hidden="true">',
          '<path d="m12 2.5 2.95 5.98 6.6.96-4.77 4.65 1.13 6.57L12 17.57l-5.91 3.1 1.13-6.57-4.77-4.65 6.6-.96L12 2.5Z"></path>',
        '</svg>'
      ].join('');
    }

    return html;
  }

  var reviews = (config.reviews || []).filter(function (review) {
    return review && review.ativo;
  });

  if (!reviews.length) return;

  var cardsHtml = reviews.map(function (review) {
    var nome = review.nome || 'Cliente';
    var inicial = nome.charAt(0).toUpperCase();

    var fotoHtml = review.foto
      ? '<img src="' + escaparHtml(review.foto) + '" alt="' + escaparHtml(nome) + '" loading="lazy">'
      : '<span>' + escaparHtml(inicial) + '</span>';

    return [
      '<article class="avaliacoes-home-card">',
        '<div class="avaliacoes-home-nota">',
          '<div class="avaliacoes-home-estrelas">',
            criarEstrelas(review.nota),
          '</div>',
          '<span>', escaparHtml(review.nota || 5), ' / 5</span>',
        '</div>',

        '<p class="avaliacoes-home-texto">“',
          escaparHtml(review.texto),
        '”</p>',

        '<footer class="avaliacoes-home-cliente">',
          '<div class="avaliacoes-home-foto">',
            fotoHtml,
          '</div>',
          '<div class="avaliacoes-home-cliente-info">',
            '<strong>', escaparHtml(nome), '</strong>',
            review.cargo
              ? '<span>' + escaparHtml(review.cargo) + '</span>'
              : '',
          '</div>',
        '</footer>',
      '</article>'
    ].join('');
  }).join('');

  var html = [
    '<section id="avaliacoes-home" class="avaliacoes-home">',
      '<div class="conteiner">',
        '<header class="avaliacoes-home-cabecalho">',
          config.etiqueta
            ? '<span class="avaliacoes-home-etiqueta">' +
              escaparHtml(config.etiqueta) +
              '</span>'
            : '',
          '<h2>', escaparHtml(config.titulo || 'Quem compra, recomenda'), '</h2>',
        '</header>',

        '<div class="avaliacoes-home-slider">',
          cardsHtml,
        '</div>',
      '</div>',
    '</section>'
  ].join('');

  var seletorInsercao = config.seletorInsercao || '#rodape';
  var $destino = $(seletorInsercao).first();

  if ($destino.length) {
    $destino.before(html);
  } else {
    $('.pagina-inicial').append(html);
  }

  var $slider = $('#avaliacoes-home .avaliacoes-home-slider');

  if (typeof $slider.slick !== 'function') {
    console.warn('Slick não foi encontrado para inicializar as avaliações.');
    return;
  }

  $slider.slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    infinite: reviews.length > 4,
    arrows: true,
    dots: false,
    autoplay: false,
    adaptiveHeight: false,

    prevArrow:
      '<button type="button" class="avaliacoes-home-seta avaliacoes-home-anterior" aria-label="Avaliação anterior">‹</button>',

    nextArrow:
      '<button type="button" class="avaliacoes-home-seta avaliacoes-home-proximo" aria-label="Próxima avaliação">›</button>',

    responsive: [
      {
        breakpoint: 1100,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2
        }
      },
      {
        breakpoint: 560,
        settings: {
          slidesToShow: 1,
          arrows: false,
          dots: true
        }
      }
    ]
  });
})();

/* ======================================================
   VÍDEO EM DESTAQUE — HOME
====================================================== */
(function () {
  var configVideo = (
    window.THEME_CONFIG &&
    window.THEME_CONFIG.videoDestaqueHome
  ) || {};

  if (!configVideo.ativo || $('#video-destaque-home').length) return;

  if (
    configVideo.somenteHome !== false &&
    !$('body').hasClass('pagina-inicial') &&
    !$('.pagina-inicial').length
  ) {
    return;
  }

  var youtubeId = String(configVideo.youtubeId || '').trim();

  if (!youtubeId) return;

  function escaparHtml(valor) {
    return String(valor || '').replace(/[&<>"']/g, function (caractere) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      }[caractere];
    });
  }

  var imagemFundo = configVideo.imagemFundo ||
    'https://img.youtube.com/vi/' + youtubeId + '/maxresdefault.jpg';

  var alinhamento = configVideo.alinhamentoTexto === 'centro'
    ? ' video-destaque-home-centro'
    : '';

  var html = [
    '<section id="video-destaque-home" class="video-destaque-home', alinhamento, '">',
      '<div class="conteiner">',
        '<div class="video-destaque-home-capa" style="background-image: url(\'', escaparHtml(imagemFundo), '\');">',
          '<div class="video-destaque-home-overlay"></div>',

          '<div class="video-destaque-home-conteudo">',
            configVideo.etiqueta
              ? '<span class="video-destaque-home-etiqueta">' +
                escaparHtml(configVideo.etiqueta) +
                '</span>'
              : '',
            '<h2>', escaparHtml(configVideo.titulo || 'Assista ao nosso vídeo'), '</h2>',
            configVideo.descricao
              ? '<p>' + escaparHtml(configVideo.descricao) + '</p>'
              : '',
            '<button type="button" class="video-destaque-home-botao" aria-label="Assistir vídeo">',
              '<span class="video-destaque-home-play-menor"><img src="https://cdn.awsli.com.br/2942/2942234/arquivos/play.svg" alt="Video Play"></span>',
              escaparHtml(configVideo.textoBotao || 'ASSISTIR AGORA'),
            '</button>',
          '</div>',

          '<button type="button" class="video-destaque-home-play" aria-label="Assistir vídeo">',
            '<span><img src="https://cdn.awsli.com.br/2942/2942234/arquivos/play.svg" alt="Video Play"></span>',
          '</button>',
        '</div>',
      '</div>',
    '</section>',

    '<div id="video-destaque-modal" class="video-destaque-modal" aria-hidden="true">',
      '<div class="video-destaque-modal-fundo"></div>',
      '<div class="video-destaque-modal-conteudo" role="dialog" aria-modal="true" aria-label="Vídeo">',
        '<button type="button" class="video-destaque-modal-fechar" aria-label="Fechar vídeo">×</button>',
        '<div class="video-destaque-modal-player"></div>',
      '</div>',
    '</div>'
  ].join('');

  var $destino = $(configVideo.seletorInsercao || '#rodape').first();

  if ($destino.length) {
    $destino.before(html);
  } else {
    $('.pagina-inicial').append(html);
  }

  function abrirVideo() {
    var $modal = $('#video-destaque-modal');

    $modal
      .addClass('video-destaque-modal-aberto')
      .attr('aria-hidden', 'false');

    $modal.find('.video-destaque-modal-player').html(
      '<iframe ' +
        'src="https://www.youtube-nocookie.com/embed/' + youtubeId + '?autoplay=1&rel=0" ' +
        'title="Vídeo em destaque" ' +
        'allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" ' +
        'allowfullscreen>' +
      '</iframe>'
    );

    $('body').addClass('video-destaque-modal-ativo');
  }

  function fecharVideo() {
    $('#video-destaque-modal')
      .removeClass('video-destaque-modal-aberto')
      .attr('aria-hidden', 'true')
      .find('.video-destaque-modal-player')
      .empty();

    $('body').removeClass('video-destaque-modal-ativo');
  }

  $(document).on(
    'click',
    '#video-destaque-home .video-destaque-home-play, #video-destaque-home .video-destaque-home-botao',
    abrirVideo
  );

  $(document).on(
    'click',
    '.video-destaque-modal-fechar, .video-destaque-modal-fundo',
    fecharVideo
  );

  $(document).on('keydown', function (evento) {
    if (evento.key === 'Escape') {
      fecharVideo();
    }
  });
})();